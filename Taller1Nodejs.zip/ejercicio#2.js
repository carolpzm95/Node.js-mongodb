function validarEdad(edad) {
    return new Promise((resolve, reject) => {
        setTimeout(() =>{
            if(edad < 18) {
                reject ("Eres menor de edad, no puedes ingresar")
            } else resolve ("Acceso permitido, Bienvenido!!!")
        }, 1000)
    })
}

validarEdad(19)
.then((r) => console.log('Promesa', r))
.catch(console.log())

async function acceso(edad) {
      try {
    const resultado = await operar(edad)
    console.log("Edad:", resultado)
  } catch (error) {
    console.error(error)
  }
}
