const clientes = [
    { id: 1, nombre: "Andrea", ingresos: 4000000, historial: "bueno" },
    { id: 2, nombre: "Daniel", ingresos: 1500000, historial: "malo" },
    { id: 3, nombre: "Pedro", ingresos: 2500000, historial: "regular" }
];


function validarIngresos(cliente, montoSolicitado) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            if (cliente.ingresos < montoSolicitado * 0.3) {
                reject(" Ingresos insuficientes para el préstamo");
                return;
            }

            resolve("Ingresos validados");

        }, 1000);
    });
}

function validarHistorial(cliente) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            if (cliente.historial === "malo") {
                reject(" Historial crediticio negativo");
                return;
            }

            resolve("Historial crediticio aprobado");

        }, 1000);
    });
}

function aprobarPrestamo(cliente, monto) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`Préstamo aprobado para ${cliente.nombre} por $${monto}`);
        }, 1000);
    });
}


async function flujoPrestamo(idCliente, montoSolicitado) {
    try {

        const cliente = clientes.find(c => c.id === idCliente);

        if (!cliente) {
            throw "❌ Cliente no existe";
        }

        console.log("Validando ingresos...");
        await validarIngresos(cliente, montoSolicitado);

        console.log("Validando historial crediticio...");
        await validarHistorial(cliente);

        console.log("Aprobando préstamo...");
        const mensaje = await aprobarPrestamo(cliente, montoSolicitado);

        console.log(mensaje);

    } catch (error) {
        console.log("Préstamo rechazado:", error);
    }
}

flujoPrestamo(1, 8000000);