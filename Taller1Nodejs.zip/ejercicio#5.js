function simuladorLogin(usuario) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (usuario !== "admin") { 
                reject("Este usuario no esta registrado")
            } else {
                resolve("Bienvenido a la plataforma, disfrute de sus beneficios!!!")
            }
        }, 1000)
    })
}

simuladorLogin("admin")
    .then((mensaje) => console.log("Mensaje:", mensaje))
    .catch((error) => console.log(error)) 

async function acceso(usuario) {
    try {
        const resultado = await simuladorLogin(usuario) 
        console.log(resultado)
    } catch (error) {
        console.error(error)
    }
}