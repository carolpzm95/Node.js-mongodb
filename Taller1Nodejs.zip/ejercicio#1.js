1	//Diseñar una promesa y un async/await que realice las operaciones aritméticas basicas
function operacionAritmetica(a, b,operacion) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (operacion=="suma"){
        suma=a+b;
      } else if(operacion=="resta"){
        resta=a-b;
      } else if(operacion== "multiplicacion"){
        multiplicacion = a*b;
      }
      if (b === 0) {
        reject("Error: División por cero");
        return;
      }
      resolve({
        resultado: a + b,
        resultado: a - b,
        resultado: a * b,
        resultado: a / b,
      });
    }, 1000);
  });
}
operacionAritmetica(10, 0, "division")
  .then((r) => console.log("Promesa:", r))
  .catch(console.log);
async function calcular(a, b) {
  try {
    const resultado = await operacionAritmetica(a, b);
    console.log("Resultados:", resultado);
  } catch (error) {
    console.error(error);
  }
}


    
    
