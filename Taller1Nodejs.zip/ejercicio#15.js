const usuariosDB = [
    { id: 1, username: "admin", password: "1234", token: "abc123" }
];

const datosDB = [
    { id: 1, producto: "Laptop", precio: 2000000 },
    { id: 2, producto: "nintendo switch", precio: 1500000 }
];


function autenticar(username, password) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            const usuario = usuariosDB.find(
                u => u.username === username && u.password === password
            );

            if (!usuario) {
                reject(" Credenciales incorrectas");
                return;
            }

            resolve(usuario.token);

        }, 1000);
    });
}

function obtenerDatos(token) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            const usuarioValido = usuariosDB.find(u => u.token === token);

            if (!usuarioValido) {
                reject("Token inválido");
                return;
            }

            resolve(datosDB);

        }, 1000);
    });
}

function procesarDatos(datos) {
    return new Promise((resolve) => {
        setTimeout(() => {

            const total = datos.reduce((acc, item) => acc + item.precio, 0);

            resolve({
                cantidadProductos: datos.length,
                totalPrecios: total
            });

        }, 1000);
    });
}

function respuestaFinal(resultado) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                status: 200,
                message: "Operación exitosa",
                data: resultado
            });
        }, 1000);
    });
}

async function simularBackend(username, password) {
    try {

        console.log("Autenticando...");
        const token = await autenticar(username, password);

        console.log("Obteniendo datos...");
        const datos = await obtenerDatos(token);

        console.log("Procesando datos...");
        const procesados = await procesarDatos(datos);

        console.log("Generando respuesta...");
        const respuesta = await respuestaFinal(procesados);

        console.log(" Respuesta final:", respuesta);

    } catch (error) {
        console.log("Error del servidor:", {
            status: 401,
            message: error
        });
    }
}

simularBackend("admin", "1234");