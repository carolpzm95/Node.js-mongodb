
function convertirMoneda(valor, moneda) {       
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (moneda === "USD") {
                resolve(`${valor} USD = ${valor * 3684} COP`)
            } else if (moneda === "EUR") {
                resolve(`${valor} EUR = ${valor * 4336} COP`)
            } else if (moneda === "Libra Esterlina") {
                resolve(`${valor} Libra Esterlina = ${valor * 4958} COP`)
            } else {
                reject(" Moneda no esta soportada")  
            }                                     
        }, 1000)
    })
}

convertirMoneda(100, "USD")
    .then((r) => console.log(r))
    .catch((error) => console.log(error))

async function hacerConversion(valor, moneda) {
    try {
        const resultado = await convertirMoneda(valor, moneda)
        console.log(resultado)
    } catch (error) {
        console.error(error)
    }
}

