

const pedido = [
    { nombre: "camiseta nike", precio: 180000, cantidad: 1 },
    { nombre: "zapatos nike air", precio: 200000, cantidad: 2 }
];

function generarID() {
    return new Promise((resolve) => {
        setTimeout(() => {

            const id = "PEDIDO-" + Math.floor(Math.random() * 10000);

            resolve(id);

        }, 1000);
    });
}


// =======================
// 2️⃣ CALCULAR TOTAL
// =======================

function calcularTotal(listaProductos) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            if (listaProductos.length === 0) {
                reject("❌ El pedido está vacío");
                return;
            }

            let total = 0;

            listaProductos.forEach(p => {
                total += p.precio * p.cantidad;
            });

            resolve(total);

        }, 1000);
    });
}


function simularEnvio(idPedido) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`Pedido ${idPedido} enviado correctamente`);
        }, 2000);
    });
}

async function procesarPedido(listaProductos) {
    try {

        console.log("Generando ID...");
        const id = await generarID();

        console.log("Calculando total...");
        const total = await calcularTotal(listaProductos);

        console.log("Simulando envío...");
        const envio = await simularEnvio(id);

        console.log(" Pedido procesado:");
        console.log("ID:", id);
        console.log("Total:", total);
        console.log(envio);

    } catch (error) {
        console.log("🚫 Error en el pedido:", error);
    }
}


procesarPedido(pedido);