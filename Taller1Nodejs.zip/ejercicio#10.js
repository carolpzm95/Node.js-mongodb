const productos = [
    { nombre: "Laptop", precio: 2000000, cantidad: 1, stock: 5 },
    { nombre: "Televisor QLED", precio: 2500000, cantidad: 2, stock: 2 },
    { nombre: "Teclado", precio: 120000, cantidad: 1, stock: 10 }
];

function validarStock(listaProductos) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            if (listaProductos.length === 0) {
                reject("No hay productos en la compra");
                return;
            }

            for (let producto of listaProductos) {
                if (producto.cantidad > producto.stock) {
                    reject(` Stock insuficiente para ${producto.nombre}`);
                    return;
                }
            }

            resolve("Compra aprobada");

        }, 1000);
    });
}


validarStock(productos)
    .then(resultado => console.log("Promesa:", resultado))
    .catch(error => console.log("Error:", error));



async function verificarCompra() {
    try {
        const resultado = await validarStock(productos);
        console.log("Async:", resultado);
    } catch (error) {
        console.log("Error:", error);
    }
}

verificarCompra();