const usuarios = [
    { id: 1, nombre: "Ana", activo: true },
    { id: 2, nombre: "Luis", activo: false }
];

const productos = [
    { nombre: "Laptop", precio: 2000000, cantidad: 1, stock: 5 },
    { nombre: "Televisor QLED", precio: 2500000, cantidad: 2, stock: 2 },
    { nombre: "Teclado", precio: 120000, cantidad: 1, stock: 10 }
];



function validarUsuario(idBuscado) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            const usuario = usuarios.find(u => u.id === idBuscado);

            if (!usuario) {
                reject(" Usuario no existe");
                return;
            }

            if (!usuario.activo) {
                reject("Usuario inactivo");
                return;
            }

            resolve(usuario);

        }, 1000);
    });
}


function validarStock(listaProductos) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            for (let producto of listaProductos) {
                if (producto.cantidad > producto.stock) {
                    reject(`Stock insuficiente para ${producto.nombre}`);
                    return;
                }
            }

            resolve(" Stock disponible");

        }, 1000);
    });
}


function calcularTotal(listaProductos) {
    return new Promise((resolve) => {
        setTimeout(() => {

            let subtotal = 0;

            listaProductos.forEach(p => {
                subtotal += p.precio * p.cantidad;
            });

            const iva = subtotal * 0.19;
            const total = subtotal + iva;

            resolve({ subtotal, iva, total });

        }, 1000);
    });
}


function confirmarCompra(usuario, total) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`🎉 Compra confirmada para ${usuario.nombre}. Total a pagar: $${total}`);
        }, 1000);
    });
}


async function flujoDeCompra(idUsuario) {
    try {

        console.log("Validando usuario...");
        const usuario = await validarUsuario(idUsuario);

        console.log("Validando stock...");
        await validarStock(productos);

        console.log("Calculando total...");
        const factura = await calcularTotal(productos);

        console.log("Confirmando compra...");
        const mensajeFinal = await confirmarCompra(usuario, factura.total);

        console.log(mensajeFinal);

    } catch (error) {
        console.log("ERROR EN LA COMPRA:", error);
    }
}

flujoDeCompra(1);