function validarUsuario(usuario, password) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (usuario !== "admin" || password !== "1234") { 
                reject(" Usuario o contraseña invalidos")
            } else {
                resolve(" Acceso permitido, Bienvenido!!!")
            }
        }, 1000)
    })
}

validarUsuario("carolina", "8765")
    .then((inicio) => console.log("Iniciaste sesión:", inicio))
    .catch((error) => console.log(error))

async function acceso(usuario, password) {   
    try {
        const resultado = await validarUsuario(usuario, password) 
        console.log(resultado)
    } catch (error) {
        console.error(error)
    }
}                