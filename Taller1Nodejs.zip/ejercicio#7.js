const notas = [4.5, 3.0, 5, 2];
function calcularPromedio(lista) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            if (lista.length === 0) {
                reject("No hay notas");
            } else {
                let suma = 0;
                 for (let i = 0; i < lista.length; i++) {
                    suma += lista[i];
                }

                let promedio = suma / lista.length;

                resolve(promedio);
            }

        }, 1000);
    });
}

calcularPromedio(notas)
    .then(r => console.log("Promedio:", r))
    .catch(e => console.log(e));