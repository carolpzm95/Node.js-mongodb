 const usuarios = [
    { id: 1, nombre: "Ana" },
    { id: 2, nombre: "Luis" },
    { id: 3, nombre: "Pedro" }

];
function BuscarUsuario (lista,idBuscado) {
   return new Promise((resolve, reject) => {
        setTimeout(() => {
            const usuarioEncontrado = lista.find (usuario => usuario.id === idBuscado);
            if(usuarioEncontrado) {
                resolve(usuarioEncontrado);
                 } else {
                 reject(`Usuario no encontrado con el id: ${idBuscado}`);
                 }  
            
        }, 1000);
});                 
}  
BuscarUsuario(usuarios,1)
    .then(resultado => console.log("Promesa:", resultado))
    .catch(error => console.log("Error:", error));
    

async function verUsuario(idBuscado) {
    try {
        const resultado = await BuscarUsuario(usuarios, idBuscado);
        console.log("Async:", resultado);
    } catch (error) {
        console.log("Error:", error);
        }     
}           
verUsuario(5);