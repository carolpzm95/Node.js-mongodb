const productos = [
    { nombre: "Laptop", precio: 2000000, cantidad: 1 },
    { nombre: "televisor QLED", precio: 2500000, cantidad: 2 },
    { nombre: "Teclado", precio: 120000, cantidad: 1 }
];

function generarFactura(listaProductos) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            if (listaProductos.length === 0) {
                reject("No hay productos en la factura");
                return;
            }

            let subtotal = 0;

            listaProductos.forEach(producto => {
                subtotal += producto.precio * producto.cantidad;
            });

            const iva = subtotal * 0.19;
            const total = subtotal + iva;

            resolve({
                subtotal,
                iva,
                total
            });

        }, 1000);
    });
}


generarFactura(productos)
    .then(resultado => console.log("Promesa:", resultado))
    .catch(error => console.log("Error:", error));



async function verFactura() {
    try {
        const resultado = await generarFactura(productos);
        console.log("Async:", resultado);
    } catch (error) {
        console.log("Error:", error);
    }
}

verFactura();
