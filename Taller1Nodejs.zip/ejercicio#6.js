const productos = [
    { nombre:"Nintendo Switch",precio: 1600000 },
    {nombre:"Xbox 360",precio:1000000 },
    { nombre:"Parlante jbl",precio:236000}
];
function FiltroPrecio (lista,precioMinimo) {
   return new Promise((resolve, reject) => {
        setTimeout(() => {
            const filtrados = lista.filter(producto => producto.precio > precioMinimo);
            if(filtrados.length > 0) {
                resolve(filtrados);
                 } else {
                reject("No hay productos mayores a ese precio");
            }
                
            
        }, 1000);

    });
}

FiltroPrecio(productos, 500000)
    .then(resultado => console.log("Promesa:", resultado))
    .catch(error => console.log("Error:", error));

async function verProductos(precioMinimo) {
    try {
        const resultado = await FiltroPrecioiltroPrecio(productos, precioMinimo);
        console.log("Async:", resultado);
    } catch (error) {
        console.log("Error:", error);
    }
}

verProductos(2000000);