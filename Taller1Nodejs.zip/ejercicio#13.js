const estudiantes = [];

function validarDatos(estudiante) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            if (!estudiante.nombre || !estudiante.email || !estudiante.edad) {
                reject("Todos los campos son obligatorios");
                return;
            }

            if (estudiante.edad < 16) {
                reject("El estudiante debe ser mayor de 16 años");
                return;
            }

            if (!estudiante.email.includes("@")) {
                reject(" Email inválido");
                return;
            }

            resolve(" Datos validados");

        }, 1000);
    });
}


function guardarEstudiante(estudiante) {
    return new Promise((resolve) => {
        setTimeout(() => {

            estudiantes.push(estudiante);

            resolve(" Estudiante guardado correctamente");

        }, 1000);
    });
}

function confirmarRegistro(estudiante) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(` Registro exitoso para ${estudiante.nombre}`);
        }, 1000);
    });
}



// ======================================
// 🔹 FLUJO COMPLETO
// ======================================

async function registrarEstudiante(estudiante) {
    try {

        console.log("Validando datos...");
        await validarDatos(estudiante);

        console.log("Guardando estudiante...");
        await guardarEstudiante(estudiante);

        console.log("Confirmando registro...");
        const mensaje = await confirmarRegistro(estudiante);

        console.log(mensaje);

    } catch (error) {
        console.log("Error en el registro:", error);
    }
}



registrarEstudiante({
    nombre: "Carolina",
    email: "carolpzm7@email.com",
    edad: 30
});