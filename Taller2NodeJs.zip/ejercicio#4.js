const carritos = [
  { cliente: "Ana", ciudad: "Medellín", productos: [{ precio: 50000, cantidad: 2 }] },
  { cliente: "Luis", ciudad: "Bogotá", productos: [] }
];

function procesarCarrito(carrito) {
  return new Promise((resolve, reject) => {
    if (carrito.productos.length === 0) {
      reject(new Error(`El carrito de ${carrito.cliente} no tiene producto`))
    } else {
      const subtotal = carrito.productos.reduce((acc, p) => acc + p.precio * p.cantidad, 0);
      const envio = carrito.ciudad === "Medellín" ? 10000 : 20000;
      const descuento = subtotal > 100000 ? subtotal * 0.05 : 0;
      const total = subtotal + envio - descuento;
      resolve({ ...carrito, subtotal, envio, descuento, total });
    }
  });
}

async function procesarCarritos(carritos) {
  const ventasOK = [];
  const ventasError = [];

  for (const carrito of carritos) {
    try {
      const resultado = await procesarCarrito(carrito);
      ventasOK.push(resultado);
    } catch (error) {
      ventasError.push({ cliente: carrito.cliente, error: error.message });
    }
  }

  const totalVentas = ventasOK.reduce((acc, v) => acc + v.total, 0);
  return { ventasOK, ventasError, totalVentas };
}

procesarCarritos(carritos).then(reporte => {
  console.log("Ventas OK:", reporte.ventasOK);
  console.log("Ventas con error:", reporte.ventasError);
  console.log("Total ventas:", reporte.totalVentas);
});