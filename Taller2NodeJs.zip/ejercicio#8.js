const usuarios = [
  { nombre: "Ana", consumo: 120, tarifa: 500 },
  { nombre: "Luis", consumo: 200, tarifa: 500 }
];
function calcularFactura(usuario) {
  return new Promise((resolve, reject) => {
     if (usuario.consumo <= 0) {
    reject(new Error(`el consumo de ${usuario.nombre} es inválido`))
} else {
        const costo = usuario.consumo * usuario.tarifa;
        const subsidio = usuario.consumo < 150 ? costo * 0.1 : 0;
        const total = costo - subsidio;
       resolve({ nombre: usuario.nombre, costo: costo, subsidio: subsidio, total: total });
}
   });
}
async function procesarUsuarios(usuarios) {
    const listaFacturas = [];

    for (const usuario of usuarios) {
        try {
            const resultado = await calcularFactura(usuario);
            listaFacturas.push(resultado);
        } catch (error) {
            console.log(error.message);
        }
    }

    const totalRecaudado = listaFacturas.reduce((acc, f) => acc + f.total, 0);
    return { listaFacturas, totalRecaudado };
}
procesarUsuarios(usuarios).then(reporte => {
    console.log("Lista facturas:", reporte.listaFacturas);
    console.log("Total recaudado:", reporte.totalRecaudado);
});