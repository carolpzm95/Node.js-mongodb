const estudiantes = [
  { nombre: "Ana", notas: [4.0, 3.5, 5.0] },
  { nombre: "Luis", notas: [] }
];
function calcularPromedio(estudiante) {
  return new Promise((resolve, reject) => {
    if (estudiante.notas.length=== 0) {
    reject(new Error(`El estudiante ${estudiante.nombre} no tiene notas `))
    }else{
        const promedio = estudiante.notas.reduce((acc, nota) => acc + nota, 0) / estudiante.notas.length;
        const estado = promedio >= 3 ? "Aprobado" : "Reprobado";
        resolve({  nombre: estudiante.nombre, promedio: promedio, estado: estado });
    }
  });
}
async function procesarEstudiantes(estudiantes) {
    const listaProcesada = [];

    for (const estudiante of estudiantes) {
        try {
            const resultado = await calcularPromedio (estudiante);
            listaProcesada.push(resultado);
        } catch (error) {
               console.log(error.message);
        
            
            
        }
      
    }
  const estudiantes = [
  { nombre: "Ana", notas: [4.0, 3.5, 5.0] },
  { nombre: "Luis", notas: [] }
];
function calcularPromedio(estudiante) {
  return new Promise((resolve, reject) => {
    if (estudiante.notas.length=== 0) {
    reject(new Error(`El estudiante ${estudiante.nombre} no tiene notas `))
    }else{
        const promedio = estudiante.notas.reduce((acc, nota) => acc + nota, 0) / estudiante.notas.length;
        const estado = promedio >= 3 ? "Aprobado" : "Reprobado";
        resolve({  nombre: estudiante.nombre, promedio: promedio, estado: estado });
    }
  });
}
async function procesarEstudiantes(estudiantes) {
    const listaProcesada = [];

    for (const estudiante of estudiantes) {
        try {
            const resultado = await calcularPromedio (estudiante);
            listaProcesada.push(resultado);
        } catch (error) {
               console.log(error.message);
        
            
            
        }
        const totalAprobados = listaProcesada.filter(e => e.estado === "Aprobado").length;
               const totalReprobados = listaProcesada.filter(e => e.estado === "reprobado").length;
    }
}

  
}

