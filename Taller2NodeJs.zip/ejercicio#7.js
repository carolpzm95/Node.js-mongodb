const ventas = [
  { vendedor: "Ana", monto: 500000 },
  { vendedor: "Luis", monto: 700000 },
  { vendedor: "Ana", monto: 300000 }
];

function calcularComision(venta) {
  return new Promise((resolve) => {
    const comision = venta.monto * 0.05;
    resolve({ vendedor: venta.vendedor, monto: venta.monto, comision: comision });
  });
}

async function procesarVentas(ventas) {
    const resumen = {};

    for (const venta of ventas) {
        try {
            const resultado = await calcularComision(venta);
            if (resumen[resultado.vendedor]) {
                resumen[resultado.vendedor] += resultado.monto;
            } else {
                resumen[resultado.vendedor] = resultado.monto;
            }
        } catch (error) {
            console.log(error.message);
        }
    }
    return { resumen };
}

procesarVentas(ventas).then(reporte => {
    console.log("Resumen ventas:", reporte.resumen);
});