const productos = [
  { nombre: "Laptop", stockActual: 3, stockMinimo: 5, precio: 2000000 },
  { nombre: "Mouse", stockActual: 20, stockMinimo: 10, precio: 50000 }
];

function verificarStock(producto) {
  return new Promise((resolve) => {
    if (producto.stockActual < producto.stockMinimo) {
      const cantidadReponer = producto.stockMinimo - producto.stockActual;
      const costoReposicion = cantidadReponer * producto.precio;
      resolve({ nombre: producto.nombre, cantidadReponer: cantidadReponer, costoReposicion: costoReposicion });
    } else {
      resolve({ nombre: producto.nombre, mensaje: "Stock suficiente" })
    }
  });
}

async function procesarProductos(productos) {
  const listaReposicion = [];

  for (const producto of productos) {
    try {
      const resultado = await verificarStock(producto);
      listaReposicion.push(resultado);
    } catch (error) {
      console.log(error.message);
    }
  }

  const costoTotalReposicion = listaReposicion.reduce((acc, p) => acc + (p.costoReposicion || 0), 0);

  return { listaReposicion, costoTotalReposicion };
}

procesarProductos(productos).then(reporte => {
  console.log("Lista reposición:", reporte.listaReposicion);
  console.log("Costo total reposición:", reporte.costoTotalReposicion);
});