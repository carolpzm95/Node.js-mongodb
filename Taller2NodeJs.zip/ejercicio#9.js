const reservas = [
  { cliente: "Ana", noches: 6, precioNoche: 100000 },
  { cliente: "Luis", noches: 2, precioNoche: 120000 }
];
function calcularReserva(reserva) {
  return new Promise((resolve, reject) => {
     if (reserva.noches <= 0) {
    reject(new Error(`la reserva de ${reserva.cliente} es inválido debe de ser mayor a 0`))
} else {
    const subtotal = reserva.noches * reserva.precioNoche;
    const impuesto = subtotal * 0.1;
    const descuento = reserva.noches > 5 ? subtotal * 0.15 : 0;
    const total=subtotal + impuesto - descuento;
    resolve({ cliente: reserva.cliente, subtotal: subtotal, impuesto: impuesto, descuento: descuento, total: total });
    }        
  });    
}

async function procesarReservas(reservas) {
    const reservasProcesadas = [];

    for (const reserva of reservas) {
        try {
            const resultado = await calcularReserva(reserva);
            reservasProcesadas.push(resultado);
        } catch (error) {
            console.log(error.message);
        }
    }

    const ingresosTotales = reservasProcesadas.reduce((acc, r) => acc + r.total, 0);
    return { reservasProcesadas, ingresosTotales };
}
procesarReservas(reservas).then(reporte => {
    console.log("Reservas procesadas:", reporte.reservasProcesadas);
    console.log("Ingresos totales:", reporte.ingresosTotales);
});