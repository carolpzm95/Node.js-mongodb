const facturas = [
  { id: 1, productos: [{ precio: 20000, cantidad: 2 }, { precio: 10000, cantidad: 1 }] },
  { id: 2, productos: [] }
];
function procesarFactura(factura) {
  return new Promise((resolve, reject) => {
    if (factura.productos.length=== 0) {
    reject(new Error(`La factura ${factura.id} no tiene producto`))

}else{
    const subtotal = factura.productos.reduce((acc, p) => acc + p.precio * p.cantidad, 0);
    const iva = subtotal * 0.19;
    const total=subtotal+iva
    resolve({ id: factura.id,subtotal: subtotal, iva: iva, total: total });
}
  });
}
async function procesarFacturas(facturas) {
    const facturasOK = [];
    const facturasError = [];

    for (const factura of facturas) {
        try {
             const resultado = await procesarFactura(factura);
             facturasOK.push(resultado);
        } catch (error) {
            facturasError.push({ id:factura.id, error:error.message });
            
        }
    }
       const totalFacturado = facturasOK.reduce((acc, f) => acc + f.total, 0);
    return { facturasOK, facturasError, totalFacturado };
}
procesarFacturas(facturas).then(reporte => {
    console.log("Facturas OK:", reporte.facturasOK);
    console.log("Facturas con error:", reporte.facturasError);
    console.log("Total facturado:", reporte.totalFacturado);
});