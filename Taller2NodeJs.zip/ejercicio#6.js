const prestamos = [
  { cliente: "Ana", monto: 10000000, tasa: 0.02, plazo: 12 },
  { cliente: "Luis", monto: 0, tasa: 0.03, plazo: 24 }
];
function calcularPrestamo(prestamo) {
  return new Promise((resolve, reject) => {
    if (prestamo.monto <= 0) {
    reject(new Error(`El préstamo de ${prestamo.cliente} es inválido`))
} else {
    const interes = prestamo.monto * prestamo.tasa * prestamo.plazo;
    const cuotaMensual = (prestamo.monto + interes) / prestamo.plazo;
    resolve({ cliente: prestamo.cliente, monto: prestamo.monto, interes: interes, cuotaMensual:cuotaMensual });
}        
  });    
}    
async function procesarPrestamos(prestamos) {
    const prestamosOK = [];
    const prestamosError = [];

    for (const prestamo of prestamos) {
        try {
            const resultado = await calcularPrestamo(prestamo);
            prestamosOK.push(resultado);
        } catch (error) {
            prestamosError.push({ cliente:prestamo.cliente, error:error.message });
        }
    }

    const totalPrestado = prestamosOK.reduce((acc, p) => acc + p.monto, 0);
    return { prestamosOK, prestamosError, totalPrestado };
}
procesarPrestamos(prestamos).then(reporte => {
    console.log("Préstamos OK:", reporte.prestamosOK);
    console.log("Préstamos con error:", reporte.prestamosError);
    console.log("Total prestado:", reporte.totalPrestado);
});