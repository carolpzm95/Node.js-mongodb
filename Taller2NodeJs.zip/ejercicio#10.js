const proyectos = [
  { nombre: "Proyecto A", presupuesto: 10000000, gastos: [2000000, 3000000] },
  { nombre: "Proyecto B", presupuesto: 5000000, gastos: [4000000, 2000000] }
];

function analizarProyecto(proyecto) {
  return new Promise((resolve) => {
    const gastoTotal = proyecto.gastos.reduce((acc, g) => acc + g, 0);
    const estado = gastoTotal > proyecto.presupuesto ? "Excedido" : "Dentro del presupuesto";
    const porcentajeEjecucion = (gastoTotal / proyecto.presupuesto) * 100;
    resolve({ nombre: proyecto.nombre, gastoTotal: gastoTotal, estado: estado, porcentajeEjecucion: porcentajeEjecucion });

  });
}
async function procesarProyectos(proyectos) {
    const resultados = [];

    for (const proyecto of proyectos) {
        try {
            const resultado = await analizarProyecto(proyecto);
            resultados.push(resultado);
        } catch (error) {
            console.log(error.message);
        }
    }

    const proyectosEnRiesgo = resultados.filter(p => p.estado === "Excedido");
    const porcentajeEjecucionGeneral = resultados.reduce((acc, p) => acc + p.porcentajeEjecucion, 0) / resultados.length;
    return { proyectosEnRiesgo, porcentajeEjecucionGeneral };
}
procesarProyectos(proyectos).then(reporte => {
    console.log("Proyectos en riesgo:", reporte.proyectosEnRiesgo);
    console.log("Porcentaje ejecución general:", reporte.porcentajeEjecucionGeneral);
});